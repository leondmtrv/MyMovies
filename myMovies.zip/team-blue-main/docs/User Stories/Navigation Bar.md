# Navigation Bar

As a user I want to be able to navigate to all the different pages.

## Notes
- Header with profile section in the right corner
- Header should be at every page (except Log-In & Sign-Up Page)
