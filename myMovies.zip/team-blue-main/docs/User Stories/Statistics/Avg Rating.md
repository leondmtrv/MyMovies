# Average Rating
As a user I want to see the average rating I have given to the movies I have watched.
