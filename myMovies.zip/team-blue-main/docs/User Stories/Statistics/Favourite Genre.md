# Favourite Movie Genre
As a user I want to know my favorite genres according to the movies I have watched. 