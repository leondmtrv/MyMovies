# Movies Watched
As a user I want to know how many movies I have watched