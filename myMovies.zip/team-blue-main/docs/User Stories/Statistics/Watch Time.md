# Total Watch Time
As a user I want to see the total time I have spent watching movies