# Remove Movie from Watch List
As a user I want to be able to remove a movie from my watch list