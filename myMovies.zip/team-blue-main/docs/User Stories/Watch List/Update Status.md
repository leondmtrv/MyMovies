# Update Status of Movie
As a user I want to be able to change a movie to "watched"