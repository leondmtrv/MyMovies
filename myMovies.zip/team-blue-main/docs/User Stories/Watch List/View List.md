# View Watch List
As a user I want to be able to view the movies I have on my watch list
