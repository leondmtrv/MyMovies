# Review Movie on Watch List
As a user I want to be able to review movie on my watch list.
