# Create Account
As a user I want to be able to create an account with a username and password so that my information is secure.

