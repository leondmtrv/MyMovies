# Delete Reviewed Movie
As a user I want to be able to remove a reviewed movie from my list.
