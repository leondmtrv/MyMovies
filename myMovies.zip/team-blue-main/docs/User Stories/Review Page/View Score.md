# View Score of Movie
As a user I want to be able to see the review I have given a movie so that I know if I liked it or not. 