# Edit Review
As a user I want to be able to edit a reviewed movie on my list if my opinion on the movie has changed. 