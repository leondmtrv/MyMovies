# View Information
As a user I want to be able to see the name, password and picture of my account.