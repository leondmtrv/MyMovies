# Edit Information
As a user I want to be able to change my password at any time and delete my account or log out.
