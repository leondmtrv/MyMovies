# Add Movie to Watch List
As a user I want to be able to add a movie to the watch list so that I know to watch it later.

## Notes
Search for movie and then present option to add it to watch list