# Search Bar
As a user I want to be able to search for movies so I can add it to my list.

## Notes
- Search bar
- Users need to input the exact name of movie