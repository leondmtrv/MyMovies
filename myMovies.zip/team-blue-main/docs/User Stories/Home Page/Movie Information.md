# Movie Information
As a user I want to be able to see information about a movie to help me decide if I want to watch it.

## Notes
- Use search bar to find movie, and then information about it is displayed