# Review Movie
As a user I want to be able to review a movie so that later on I can see what movies I have liked/disliked.

## Notes
Search for movie and then add to review list, which asks user to review movie. 