# Add Movie to Review List
As a user I want to be able to add a movie to the list of movies I have already seen.

## Notes
- Search for movie and then present option to add it to review list