# Trending Movies
As a user I want to be able to see current trending movies to help me choose a movie to watch.

## Notes
- Three movies in the centre
