package com.mymovies.mymovies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMoviesApplicationTests {

    @Test
    void contextLoads() {
    }

}
